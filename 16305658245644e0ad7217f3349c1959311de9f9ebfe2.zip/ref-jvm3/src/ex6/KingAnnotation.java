package ex6;

public @interface KingAnnotation {
}
