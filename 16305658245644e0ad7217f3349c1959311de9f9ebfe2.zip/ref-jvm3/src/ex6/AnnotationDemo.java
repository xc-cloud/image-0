package ex6;

@KingAnnotation
public class AnnotationDemo {
    @KingAnnotation
    public void test(@KingAnnotation  int a){
    }
}
