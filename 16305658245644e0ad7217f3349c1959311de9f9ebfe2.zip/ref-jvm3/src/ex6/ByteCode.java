package ex6;
/**
 * @author King老师
 * 字节码分析
 */
public class ByteCode {
    public ByteCode(){
    }
}
