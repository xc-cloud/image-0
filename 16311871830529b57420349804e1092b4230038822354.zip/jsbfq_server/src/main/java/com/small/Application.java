package com.small;

import com.alibaba.fastjson.JSON;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

/**
 * @author small
 * @version 1.0
 * @date 2021/9/9 下午2:09
 */
@SpringBootApplication
@Controller
public class Application {
    /**
     * 使用方法 ：
     * 在本地hosts文件中，添加127.0.0.1  reg.drmfab.cn
     * 启动应用，指定端口80，然后使用金狮播放器，填写任意注册码即可。仅支持享学课堂VIP视频播放
     * @return
     */
    @GetMapping("/official/player/v1/phoneplayer/index.php")
    @ResponseBody
    public String official() {
        Map<String, Object> result = new HashMap<>();
        result.put("code",200);
        result.put("result","成功播放");//
        result.put("play_key","a3944e3ac807b99c57723c802b6432d9");
        result.put("group_id","xx02");
        result.put("stu_validity","2099-11-30");
        result.put("watermark",1);
        result.put("watermarkInfo",new HashMap<String,Object>(){{
            put("content","老子不告诉你");
            put("marquee","1");
            put("size","18");
            put("color1","#409EFF");
        }});
        return JSON.toJSONString(result);
    }
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
